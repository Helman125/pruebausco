package com.example.usco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UscoApplication {

	public static void main(String[] args) {
		SpringApplication.run(UscoApplication.class, args);
	}

}

package com.example.usco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UscoApplicationTests {

	@Test
	void contextLoads() {
	}

}
